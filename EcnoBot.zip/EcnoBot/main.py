"""
This is a echo bot.
It echoes any incoming text messages.
"""

import logging

from aiogram import Bot, Dispatcher, executor, types

API_TOKEN = '5382507296:AAERol0TfJCLYn9pXYbOGPfw_rzNqvHtUbQ'

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def welcome(message: types.Message):
    await message.reply("Hi!\nI'm EchoBot!\nPowered by aiogram.")

@dp.message_handler(commands=['help'])
async def support(message: types.Message):
    await message.answer("Hi!\nI'm EchoBot!\nPowered by aiogram.")

@dp.message_handler(regexp='(^cat[s]?$|puss)')
async def cats(message: types.Message):
    with open('data/cats.jpg', 'rb') as photo:


        await message.reply_photo(photo, caption='Cats are here 😺')


@dp.message_handler()
async def echo(message: types.Message):

    print(message)
    await message.answer(message.text + "🥰" + message.from_user.first_name)
    await message.reply_photo(types.InputFile("ac252ca0.jpg"))

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)